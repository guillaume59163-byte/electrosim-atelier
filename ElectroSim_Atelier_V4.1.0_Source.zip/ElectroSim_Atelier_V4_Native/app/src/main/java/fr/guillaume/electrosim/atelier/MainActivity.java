package fr.guillaume.electrosim.atelier;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final int REQUEST_EXPORT = 4101;
    private static final int REQUEST_IMPORT = 4102;
    private static final String PREFS = "electrosim_atelier";
    private static final String STATE_KEY = "projects_json";

    private WebView webView;
    private ValueCallback<Uri[]> fileChooserCallback;
    private String pendingExport = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WebView.setWebContentsDebuggingEnabled(false);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileChooserCallback != null) {
                    fileChooserCallback.onReceiveValue(null);
                }
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                startActivityForResult(intent, REQUEST_IMPORT);
                return true;
            }
        });
        webView.addJavascriptInterface(new ElectroSimBridge(), "ElectroSimAndroid");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    @Deprecated
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMPORT) {
            if (fileChooserCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[] { data.getData() };
                }
                fileChooserCallback.onReceiveValue(result);
                fileChooserCallback = null;
            }
            return;
        }
        if (requestCode == REQUEST_EXPORT && resultCode == RESULT_OK && data != null) {
            Uri uri = data.getData();
            if (uri != null) {
                try (OutputStream stream = getContentResolver().openOutputStream(uri, "wt")) {
                    if (stream == null) throw new IllegalStateException("Flux indisponible");
                    stream.write(pendingExport.getBytes(StandardCharsets.UTF_8));
                    stream.flush();
                    Toast.makeText(this, "Export JSON enregistré", Toast.LENGTH_SHORT).show();
                } catch (Exception exception) {
                    Toast.makeText(this, "Export impossible", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    @Override
    protected void onDestroy() {
        if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private final class ElectroSimBridge {
        @JavascriptInterface
        public boolean saveState(String json) {
            return getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putString(STATE_KEY, json).commit();
        }

        @JavascriptInterface
        public String loadState() {
            return getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(STATE_KEY, null);
        }

        @JavascriptInterface
        public void exportFile(String filename, String mime, String text) {
            runOnUiThread(() -> {
                pendingExport = text == null ? "" : text;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType(mime == null || mime.isEmpty() ? "application/json" : mime);
                intent.putExtra(Intent.EXTRA_TITLE,
                        filename == null || filename.isEmpty() ? "electrosim-atelier.json" : filename);
                startActivityForResult(intent, REQUEST_EXPORT);
            });
        }

        @JavascriptInterface
        public void printPage(String jobName) {
            runOnUiThread(() -> {
                String safeName = jobName == null || jobName.trim().isEmpty()
                        ? "ÉlectroSim Atelier" : jobName;
                PrintManager manager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (manager != null) {
                    PrintAttributes attributes = new PrintAttributes.Builder()
                            .setMediaSize(PrintAttributes.MediaSize.ISO_A4.asLandscape())
                            .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                            .build();
                    manager.print(safeName, webView.createPrintDocumentAdapter(safeName), attributes);
                }
            });
        }
    }
}
