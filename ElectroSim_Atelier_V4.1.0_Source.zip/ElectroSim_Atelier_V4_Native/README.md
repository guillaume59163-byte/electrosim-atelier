# ÉlectroSim Atelier V4.1

Application Android hors ligne de préparation de tableaux électriques.

La version Android conserve les chantiers localement, permet l'export/import JSON et l'impression du dossier. Le paquet Android est construit automatiquement par GitHub Actions après chaque mise à jour de la branche `main`.
